import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

const initialState = {
    users: ["somethind is hare"],
    loading: false,
    error: ""
}

export const getUserData = createAsyncThunk(
    'user/getUsers',
    async () => {
        try {
            const res = await fetch("https://jsonplaceholder.typicode.com/users")
            const data = await res.json()
            return data
        } catch (error) {
            console.log(error);
            console.log(error.message);
        }
    }
)

const userSclice = createSlice({
    name: "user",
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder.addCase(getUserData.rejected, (state)=> {
            state.error = true
        })
        builder.addCase(getUserData.fulfilled, (state, action) => {
            console.log("action => ", action);
            state.users = action.payload
        })
        builder.addCase(getUserData.pending, (state) => {
            state.loading = true
        })
    }
})

export default userSclice.reducer